// ======================================
// FIFA WORLD CUP SIMULATOR
// script.js
// Part 1
// ======================================


// ---------- DOM ELEMENTS ----------

const startBtn =
    document.getElementById("startBtn");

const autoBtn =
    document.getElementById("autoBtn");

const nextBtn =
    document.getElementById("nextBtn");

const resetBtn =
    document.getElementById("resetBtn");


const teamList =
    document.getElementById("teamList");

const searchBox =
    document.getElementById("search");


const groupContainer =
    document.getElementById("groupContainer");

const matchContainer =
    document.getElementById("matchContainer");

const knockoutContainer =
    document.getElementById("knockoutContainer");

const championContainer =
    document.getElementById("championContainer");


// ---------- TOURNAMENT STATE ----------

let tournamentStarted = false;

let tournamentFinished = false;

let currentPhase = "Setup";

let selectedTeams = [];


// ---------- SETTINGS ----------

const MIN_RATING = 0;

const MAX_RATING = 1000;


// ---------- HELPER FUNCTIONS ----------

function clamp(value,min,max){

    return Math.max(
        min,
        Math.min(value,max)
    );

}


function randomInt(min,max){

    return Math.floor(
        Math.random() *
        (max-min+1)
    ) + min;

}


function shuffle(array){

    let copy=[...array];


    for(let i=copy.length-1;i>0;i--){

        let j =
            Math.floor(
                Math.random()*(i+1)
            );


        [
            copy[i],
            copy[j]
        ] =
        [
            copy[j],
            copy[i]
        ];

    }


    return copy;

}


// ---------- RESET UI ----------

function clearScreen(){

    groupContainer.innerHTML="";

    matchContainer.innerHTML="";

    knockoutContainer.innerHTML="";

    championContainer.textContent =
        "No champion yet.";

}


// ---------- RESET GAME ----------

function resetGame(){

    tournamentStarted=false;

    tournamentFinished=false;

    currentPhase="Setup";

    selectedTeams=[];


    clearScreen();


    teams.forEach(team=>{

        resetStats(team);

    });


    renderTeams();

}


// ---------- STARTUP ----------

function initialize(){

    loadTeams();

    loadRatings();

    renderTeams();

}


initialize();// ======================================
// FIFA WORLD CUP SIMULATOR
// script.js
// Part 2
// ======================================


// ---------- RENDER TEAM EDITOR ----------

function renderTeams(){

    teamList.innerHTML = "";


    teams.forEach((team,index)=>{


        const row =
            document.createElement("div");


        row.className = "teamRow";


        const name =
            document.createElement("span");


        name.textContent =
            `${index+1}. ${team.name}`;



        const input =
            document.createElement("input");


        input.type = "number";

        input.min = MIN_RATING;

        input.max = MAX_RATING;

        input.value =
            team.rating;



        input.addEventListener(
            "change",
            ()=>{


                let value =
                    parseInt(
                        input.value
                    );


                if(isNaN(value)){

                    value=0;

                }


                value =
                    clamp(
                        value,
                        MIN_RATING,
                        MAX_RATING
                    );


                team.rating =
                    value;


                input.value =
                    value;


                saveRatings();


            }
        );


        row.appendChild(name);

        row.appendChild(input);


        teamList.appendChild(row);


    });

}



// ---------- SEARCH TEAMS ----------

function filterTeams(){

    const text =
        searchBox.value
        .toLowerCase();



    const rows =
        document.querySelectorAll(
            ".teamRow"
        );



    rows.forEach(row=>{


        const name =
            row
            .textContent
            .toLowerCase();



        if(name.includes(text)){


            row.style.display =
                "flex";


        }else{


            row.style.display =
                "none";


        }


    });

}


searchBox.addEventListener(
    "input",
    filterTeams
);



// ---------- SORT BY RATING ----------

function sortByRating(){

    teams.sort(
        (a,b)=>
            b.rating-a.rating
    );


    renderTeams();

}



// ---------- SORT ALPHABETICALLY ----------

function sortAlphabetical(){

    teams.sort(
        (a,b)=>
            a.name.localeCompare(
                b.name
            )
    );


    renderTeams();

}



// ---------- RANDOM RATINGS ----------

function randomizeRatings(){

    teams.forEach(team=>{

        team.rating =
            randomInt(
                MIN_RATING,
                MAX_RATING
            );

    });


    saveRatings();

    renderTeams();

}



// ---------- DEFAULT RATINGS ----------

let defaultRatings =
    teams.map(team=>({

        name:team.name,

        rating:team.rating

    }));


function restoreRatings(){

    defaultRatings.forEach(saved=>{


        const team =
            teams.find(
                t =>
                t.name === saved.name
            );


        if(team){

            team.rating =
                saved.rating;

        }


    });


    saveRatings();

    renderTeams();

}// ======================================
// FIFA WORLD CUP SIMULATOR
// script.js
// Part 3
// ======================================


// ---------- TOURNAMENT SETTINGS ----------

const TEAMS_PER_GROUP = 4;


// ---------- START TOURNAMENT ----------

function startTournament(){

    if(tournamentStarted)
        return;


    tournamentStarted = true;

    tournamentFinished = false;

    currentPhase = "Group Stage";


    clearScreen();


    selectedTeams =
        shuffle(
            [...teams]
        );


    createGroups();


    renderGroups();


    createFixtures();


    renderFixtures();

}



// ---------- CREATE GROUPS ----------

function createGroups(){

    groups = [];


    let index = 0;


    for(
        let i=0;
        i < selectedTeams.length;
        i += TEAMS_PER_GROUP
    ){


        const group = {

            name:
                "Group " +
                (
                    groups.length + 1
                ),

            teams:[]

        };


        for(
            let j=0;
            j < TEAMS_PER_GROUP;
            j++
        ){


            const team =
                selectedTeams[index];


            resetStats(team);


            group.teams.push(team);


            index++;


        }


        groups.push(group);


    }

}



// ---------- RENDER GROUPS ----------

function renderGroups(){

    groupContainer.innerHTML="";


    groups.forEach(group=>{


        const box =
            document.createElement("div");


        box.className =
            "group";


        box.innerHTML = `

        <h3>${group.name}</h3>

        <table>

        <tr>

        <th>Team</th>
        <th>Rating</th>
        <th>Pts</th>
        <th>GD</th>

        </tr>

        </table>

        `;


        const table =
            box.querySelector("table");



        group.teams.forEach(team=>{


            const row =
                document.createElement("tr");


            row.innerHTML = `

            <td>${team.name}</td>

            <td>${team.rating}</td>

            <td>${team.points}</td>

            <td>${team.gd}</td>

            `;


            table.appendChild(row);


        });



        groupContainer.appendChild(box);


    });


}



// ---------- CREATE GROUP FIXTURES ----------

function createFixtures(){

    fixtures=[];


    groups.forEach(group=>{


        const t =
            group.teams;


        fixtures.push(
            {
                home:t[0],
                away:t[1]
            },

            {
                home:t[2],
                away:t[3]
            },

            {
                home:t[0],
                away:t[2]
            },

            {
                home:t[1],
                away:t[3]
            },

            {
                home:t[0],
                away:t[3]
            },

            {
                home:t[1],
                away:t[2]
            }
        );


    });


}



// ---------- RENDER FIXTURES ----------

function renderFixtures(){

    matchContainer.innerHTML="";


    fixtures.forEach(
        (match,index)=>{


        const div =
            document.createElement("div");


        div.className =
            "match";


        div.textContent =
            `Match ${index+1}: 
            ${match.home.name} vs 
            ${match.away.name}`;


        matchContainer.appendChild(div);


    });


}



// ---------- BUTTON CONNECTION ----------

startBtn.addEventListener(
    "click",
    startTournament
);// ======================================
// FIFA WORLD CUP SIMULATOR
// script.js
// Part 4
// ======================================


// ---------- DISPLAY MATCH RESULT ----------

function showResult(result){

    const div =
        document.createElement("div");


    div.className =
        "match";


    div.innerHTML = `

    <b>${result.home.name}</b>

    ${result.homeGoals}

    -

    ${result.awayGoals}

    <b>${result.away.name}</b>

    `;


    matchContainer.prepend(div);

}



// ---------- PLAY ONE MATCH ----------

function playNextMatch(){

    if(currentMatch >= fixtures.length){

        finishGroups();

        return;

    }


    const match =
        fixtures[currentMatch];


    const result =
        playFixture(match);


    showResult(result);


    currentMatch++;


    renderGroups();

    updateTournamentInfo();


}



// ---------- AUTOMATIC GROUP PLAY ----------

function automaticPlay(){

    if(!tournamentStarted)
        return;


    if(currentPhase === "Group Stage"){


        while(
            currentMatch <
            fixtures.length
        ){


            const match =
                fixtures[currentMatch];


            const result =
                playFixture(match);


            showResult(result);


            currentMatch++;


        }


        renderGroups();


        finishGroups();


        currentPhase =
            "Knockout Stage";


        return;

    }



    if(currentPhase === "Knockout Stage"){


        simulateEntireTournament();


        tournamentFinished =
            true;


    }

}



// ---------- FINISH GROUP STAGE ----------

function finishGroups(){


    let qualified=[];


    groups.forEach(group=>{


        sortGroup(group);


        qualified.push(
            group.teams[0]
        );


    });



    let runnersUp=[];


    groups.forEach(group=>{


        runnersUp.push(
            group.teams[1]
        );


    });



    runnersUp.sort(
        (a,b)=>{


            if(b.points !== a.points)

                return b.points-a.points;


            if(b.gd !== a.gd)

                return b.gd-a.gd;


            return b.gf-a.gf;


        }
    );



    qualified.push(
        ...runnersUp.slice(0,11)
    );



    createKnockout(qualified);


}



// ---------- UPDATE TOURNAMENT INFO ----------

function updateTournamentInfo(){


    const round =
        document.getElementById(
            "currentRound"
        );


    const played =
        document.getElementById(
            "matchesPlayed"
        );


    if(round){

        round.textContent =
            currentPhase;

    }


    if(played){

        played.textContent =
            currentMatch;

    }

}



// ---------- BUTTONS ----------

autoBtn.addEventListener(
    "click",
    automaticPlay
);



nextBtn.addEventListener(
    "click",
    playNextMatch
);// ======================================
// FIFA WORLD CUP SIMULATOR
// script.js
// Part 5
// ======================================


// ---------- TOURNAMENT STATISTICS ----------

let tournamentStats = {

    totalGoals: 0,

    biggestWin: null,

    biggestUpset: null,

    champion: null

};


// ---------- TRACK MATCH ----------

function trackMatch(result){


    tournamentStats.totalGoals +=
        result.homeGoals +
        result.awayGoals;



    const goalDifference =
        Math.abs(
            result.homeGoals -
            result.awayGoals
        );



    if(
        !tournamentStats.biggestWin ||
        goalDifference >
        tournamentStats.biggestWin.difference
    ){

        tournamentStats.biggestWin = {

            home: result.home.name,

            away: result.away.name,

            score:
            `${result.homeGoals}-${result.awayGoals}`,

            difference:
            goalDifference

        };

    }



    const ratingDifference =
        Math.abs(
            result.home.rating -
            result.away.rating
        );



    if(
        ratingDifference > 200
    ){

        const winner =
            result.winner;


        const loser =
            winner === result.home
            ? result.away
            : result.home;



        if(
            !tournamentStats.biggestUpset ||
            ratingDifference >
            tournamentStats.biggestUpset.difference
        ){

            tournamentStats.biggestUpset = {

                winner:
                winner.name,

                loser:
                loser.name,

                difference:
                ratingDifference

            };

        }

    }

}



// ---------- RANKING UPDATE ----------

function updateRatings(result){

    const winner =
        result.winner;


    if(!winner)
        return;



    const loser =
        winner === result.home
        ? result.away
        : result.home;



    const difference =
        winner.rating -
        loser.rating;



    if(difference < 0){

        winner.rating =
            clamp(
                winner.rating + 5,
                0,
                1000
            );


        loser.rating =
            clamp(
                loser.rating - 5,
                0,
                1000
            );

    }

    else{

        winner.rating =
            clamp(
                winner.rating + 1,
                0,
                1000
            );


        loser.rating =
            clamp(
                loser.rating - 1,
                0,
                1000
            );

    }


    saveRatings();

}



// ---------- SAVE TOURNAMENT ----------

function saveTournament(){


    const saveData = {

        teams,

        groups,

        fixtures,

        knockout,

        currentPhase,

        currentMatch,

        tournamentStarted,

        tournamentFinished,

        tournamentStats

    };


    localStorage.setItem(

        "worldCupSave",

        JSON.stringify(saveData)

    );



}



// ---------- LOAD TOURNAMENT ----------

function loadTournament(){


    const saved =
        localStorage.getItem(
            "worldCupSave"
        );



    if(!saved)
        return;



    const data =
        JSON.parse(saved);



    teams =
        data.teams;


    groups =
        data.groups;


    fixtures =
        data.fixtures;


    knockout =
        data.knockout;


    currentPhase =
        data.currentPhase;


    currentMatch =
        data.currentMatch;


    tournamentStarted =
        data.tournamentStarted;


    tournamentFinished =
        data.tournamentFinished;


    tournamentStats =
        data.tournamentStats;



    renderTeams();

    renderGroups();

    renderKnockout();

}



// ---------- SHOW FINAL RESULTS ----------

function showStatistics(){


    const stats =
        document.getElementById(
            "statistics"
        );


    if(!stats)
        return;



    stats.innerHTML = `

    <h2>Tournament Statistics</h2>

    <p>
    Goals:
    ${tournamentStats.totalGoals}
    </p>


    <p>
    Biggest Win:
    ${
        tournamentStats.biggestWin
        ?
        tournamentStats.biggestWin.score
        :
        "None"
    }
    </p>


    <p>
    Biggest Upset:
    ${
        tournamentStats.biggestUpset
        ?
        tournamentStats.biggestUpset.winner
        :
        "None"
    }
    </p>

    `;


}



// ---------- FINAL RESET ----------

function resetEverything(){

    localStorage.removeItem(
        "worldCupSave"
    );


    localStorage.removeItem(
        "fifaRatings"
    );


    location.reload();

}



// ---------- EXTRA BUTTONS ----------

const saveBtn =
    document.getElementById("saveBtn");


const loadBtn =
    document.getElementById("loadBtn");


if(saveBtn){

    saveBtn.addEventListener(
        "click",
        saveTournament
    );

}


if(loadBtn){

    loadBtn.addEventListener(
        "click",
        loadTournament
    );

}