// ======================================
// FIFA WORLD CUP SIMULATOR
// simulation.js
// Part 1
// ======================================


// ---------- GOAL SIMULATION ----------

function generateGoals(teamA, teamB){

    const strengthA = teamA.rating / 1000;
    const strengthB = teamB.rating / 1000;


    // Base attacking power

    const attackA =
        0.4 +
        strengthA * 2.8;


    const attackB =
        0.4 +
        strengthB * 2.8;


    // Random goal generation

    const goalsA =
        Math.floor(
            Math.random() *
            (attackA + 2)
        );


    const goalsB =
        Math.floor(
            Math.random() *
            (attackB + 2)
        );


    return {

        home: Math.min(goalsA, MAX_GOALS),

        away: Math.min(goalsB, MAX_GOALS)

    };

}


// ---------- WIN PROBABILITY ----------

function winChance(teamA, teamB){

    const difference =
        teamA.rating - teamB.rating;


    const chance =
        0.5 +
        difference / 2000;


    return clamp(
        chance,
        0.05,
        0.95
    );

}


// ---------- PLAY A MATCH ----------

function simulateMatch(home, away){

    let score =
        generateGoals(home, away);


    let homeGoals =
        score.home;

    let awayGoals =
        score.away;


    return {

        home,

        away,

        homeGoals,

        awayGoals,

        winner:null

    };

}


// ---------- UPDATE STANDINGS ----------

function updateStandings(result){

    const home =
        result.home;

    const away =
        result.away;


    home.played++;

    away.played++;


    home.gf += result.homeGoals;

    home.ga += result.awayGoals;


    away.gf += result.awayGoals;

    away.ga += result.homeGoals;


    home.gd =
        home.gf -
        home.ga;

    away.gd =
        away.gf -
        away.ga;



    if(result.homeGoals > result.awayGoals){

        home.points += POINTS_WIN;

        home.wins++;

        away.losses++;

        result.winner = home;

    }


    else if(result.awayGoals > result.homeGoals){

        away.points += POINTS_WIN;

        away.wins++;

        home.losses++;

        result.winner = away;

    }


    else{

        home.points += POINTS_DRAW;

        away.points += POINTS_DRAW;

        home.draws++;

        away.draws++;

    }


    return result;

}


// ---------- PLAY FIXTURE ----------

function playFixture(match){

    const result =
        simulateMatch(
            match.home,
            match.away
        );


    updateStandings(result);


    return result;

}// ======================================
// FIFA WORLD CUP SIMULATOR
// simulation.js
// Part 2
// ======================================


// ---------- DISPLAY RESULT ----------

function displayMatchResult(result){

    const div = document.createElement("div");

    div.className = "match";

    div.innerHTML = `

        <strong>${result.home.name}</strong>

        ${result.homeGoals}

        -

        ${result.awayGoals}

        <strong>${result.away.name}</strong>

    `;

    matchContainer.prepend(div);

}


// ---------- PLAY NEXT MATCH ----------

function playNextMatch(){

    if(currentMatch >= fixtures.length){

        finishGroups();

        return;

    }


    const match = fixtures[currentMatch];


    const result =
        playFixture(match);


    displayMatchResult(result);


    currentMatch++;


    renderGroups();

}


// ---------- PLAY ENTIRE ROUND ----------

function automaticPlay(){

    if(!tournamentStarted)
        return;


    while(currentMatch < fixtures.length){

        const match =
            fixtures[currentMatch];


        const result =
            playFixture(match);


        displayMatchResult(result);


        currentMatch++;

    }


    renderGroups();


    finishGroups();

}


// ---------- GROUP STANDINGS ----------

function getGroupStandings(group){

    sortGroup(group);

    return group.teams;

}


// ---------- ADVANCE FROM GROUPS ----------

function finishGroups(){

    let qualified = [];


    groups.forEach(group=>{

        const standings =
            getGroupStandings(group);


        // Top team automatically advances

        qualified.push(
            standings[0]
        );


    });


    // Collect runners-up

    let runnersUp = [];


    groups.forEach(group=>{

        const standings =
            getGroupStandings(group);


        runnersUp.push(
            standings[1]
        );

    });



    // Need 11 best runners-up

    runnersUp.sort((a,b)=>{

        if(b.points !== a.points)

            return b.points - a.points;


        if(b.gd !== a.gd)

            return b.gd - a.gd;


        return b.gf - a.gf;

    });



    qualified.push(
        ...runnersUp.slice(0,11)
    );


    createKnockout(qualified);

}


// ---------- CREATE KNOCKOUT LIST ----------

function createKnockout(qualified){

    knockout = [];

    shuffle(qualified);


    for(let i=0;i<qualified.length;i+=2){

        knockout.push({

            home: qualified[i],

            away: qualified[i+1],

            winner:null

        });

    }


    currentRound = "Round of 64";


    renderKnockout();

}// ======================================
// FIFA WORLD CUP SIMULATOR
// simulation.js
// Part 3
// ======================================


// ---------- KNOCKOUT MATCH ----------

function simulateKnockoutMatch(match){

    let result =
        simulateMatch(
            match.home,
            match.away
        );


    // If tied, go to extra time

    if(result.homeGoals === result.awayGoals){

        let extraHome =
            randomInt(0,2);

        let extraAway =
            randomInt(0,2);


        result.homeGoals += extraHome;

        result.awayGoals += extraAway;


    }


    // Still tied = penalties

    if(result.homeGoals === result.awayGoals){

        let homePens =
            randomInt(3,6);

        let awayPens =
            randomInt(3,6);


        while(homePens === awayPens){

            homePens =
                randomInt(3,6);

            awayPens =
                randomInt(3,6);

        }


        if(homePens > awayPens){

            result.winner =
                match.home;

        }else{

            result.winner =
                match.away;

        }


        result.penalties =
            `${homePens}-${awayPens}`;

    }


    else if(result.homeGoals > result.awayGoals){

        result.winner =
            match.home;

    }

    else{

        result.winner =
            match.away;

    }


    return result;

}


// ---------- PLAY KNOCKOUT ROUND ----------

function playKnockoutRound(){

    let winners = [];


    knockout.forEach(match=>{

        const result =
            simulateKnockoutMatch(match);


        displayKnockoutResult(result);


        winners.push(
            result.winner
        );

    });


    createNextRound(winners);

}


// ---------- DISPLAY KNOCKOUT RESULT ----------

function displayKnockoutResult(result){

    const div =
        document.createElement("div");


    div.className = "game";


    let penaltyText = "";


    if(result.penalties){

        penaltyText =
        ` (Pens ${result.penalties})`;

    }


    div.innerHTML = `

    ${result.home.name}

    ${result.homeGoals}

    -

    ${result.awayGoals}

    ${result.away.name}

    <br>

    Winner:

    <b>${result.winner.name}</b>

    ${penaltyText}

    `;


    knockoutContainer.prepend(div);

}


// ---------- CREATE NEXT ROUND ----------

function createNextRound(winners){

    if(winners.length === 1){

        declareChampion(
            winners[0]
        );

        return;

    }


    knockout = [];


    shuffle(winners);


    for(let i=0;i<winners.length;i+=2){

        knockout.push({

            home:winners[i],

            away:winners[i+1],

            winner:null

        });

    }


    // Update round name

    switch(winners.length){

        case 32:
            currentRound="Round of 32";
            break;

        case 16:
            currentRound="Round of 16";
            break;

        case 8:
            currentRound="Quarterfinals";
            break;

        case 4:
            currentRound="Semifinals";
            break;

        case 2:
            currentRound="Final";
            break;

    }


    renderKnockout();

}


// ---------- AUTOMATIC KNOCKOUT PLAY ----------

function automaticKnockout(){

    while(knockout.length > 0){

        playKnockoutRound();

    }

}


// ---------- CHAMPION ----------

function declareChampion(team){

    championContainer.innerHTML = `

    🏆 ${team.name}

    <br>

    World Cup Champion!

    `;

    currentRound="Finished";

}// ======================================
// FIFA WORLD CUP SIMULATOR
// simulation.js
// Part 4
// ======================================


// ---------- RENDER KNOCKOUT ----------

function renderKnockout(){

    knockoutContainer.innerHTML = "";

    const title = document.createElement("h3");

    title.textContent = currentRound;

    knockoutContainer.appendChild(title);


    knockout.forEach((match,index)=>{

        const div =
            document.createElement("div");


        div.className = "game";


        div.innerHTML = `

        Match ${index+1}

        <br>

        ${match.home.name}

        vs

        ${match.away.name}

        `;


        knockoutContainer.appendChild(div);

    });

}


// ---------- PLAY CURRENT ROUND ----------

function playCurrentRound(){

    if(knockout.length === 0)
        return;


    playKnockoutRound();

}


// ---------- TOURNAMENT STATISTICS ----------

function getTopScoringTeam(){

    let best = teams[0];


    teams.forEach(team=>{

        if(team.gf > best.gf){

            best = team;

        }

    });


    return best;

}


function getBestDefense(){

    let best = teams[0];


    teams.forEach(team=>{

        if(team.ga < best.ga){

            best = team;

        }

    });


    return best;

}


// ---------- UPDATE STATISTICS DISPLAY ----------

function updateStatistics(){

    const scorer =
        getTopScoringTeam();


    const defense =
        getBestDefense();


    const top =
        document.getElementById("topScorer");


    const defenseBox =
        document.getElementById("bestDefense");


    const goals =
        document.getElementById("mostGoals");


    if(top){

        top.textContent =
            scorer.name;

    }


    if(defenseBox){

        defenseBox.textContent =
            defense.name;

    }


    if(goals){

        let total = 0;


        teams.forEach(team=>{

            total += team.gf;

        });


        goals.textContent =
            total;

    }

}


// ---------- TOURNAMENT STATUS ----------

function updateTournamentInfo(){

    const round =
        document.getElementById("currentRound");


    const played =
        document.getElementById("matchesPlayed");


    const matchday =
        document.getElementById("matchday");


    if(round){

        round.textContent =
            currentRound || "Not Started";

    }


    if(played){

        played.textContent =
            currentMatch;

    }


    if(matchday){

        matchday.textContent =
            Math.floor(currentMatch / 12);

    }

}


// ---------- FULL AUTO SIMULATION ----------

function simulateEntireTournament(){

    automaticPlay();


    while(knockout.length > 0){

        playCurrentRound();

    }


    updateStatistics();

    updateTournamentInfo();

}


// ---------- RESET EVERYTHING ----------

function fullReset(){

    resetTournament();


    currentRound = "";


    knockoutContainer.innerHTML="";


    championContainer.textContent =
        "No champion yet.";

}


// ---------- EXPORT RESULTS ----------

function exportResults(){

    const data = {

        champion:
            championContainer.textContent,

        teams,

        groups,

        knockout

    };


    const file =
        JSON.stringify(
            data,
            null,
            2
        );


    console.log(file);

}